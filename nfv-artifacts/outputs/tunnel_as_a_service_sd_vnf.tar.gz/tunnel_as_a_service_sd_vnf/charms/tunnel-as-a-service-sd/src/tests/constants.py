# @Author: Daniel Gomes
# @Date:   2022-11-12 11:54:34
# @Email:  dagomes@av.it.pt
# @Copyright: Insituto de Telecomunicações - Aveiro, Aveiro, Portugal
# @Last Modified by:   Daniel Gomes
# @Last Modified time: 2022-11-12 11:55:06
PEER_LIFECYCLE_START_TS = "LIFECYCLE_START_TS"
WG_INSTALLED_TS = "WG_INSTALLED_TS"
DNS_SD_REGISTER_TS = "DNS_SD_REGISTER_TS"
WAITING_DNS_INFO_TS = "WAITING_DNS_INFO_TS"
GOT_DNS_INFO_TS = "GOT_DNS_INFO_TS"
CONNECTION_SUCCESS_TS = "CONNECTION_SUCCESS_TS"
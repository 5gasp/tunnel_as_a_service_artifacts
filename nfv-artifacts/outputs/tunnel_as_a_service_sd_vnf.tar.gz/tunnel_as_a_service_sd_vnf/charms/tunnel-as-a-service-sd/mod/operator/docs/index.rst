
Welcome to The Operator Framework's documentation!
==================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

ops package
===========

.. automodule:: ops

Submodules
----------

ops.charm module
----------------

.. automodule:: ops.charm

ops.framework module
--------------------

.. automodule:: ops.framework

ops.jujuversion module
----------------------

.. automodule:: ops.jujuversion

ops.log module
--------------

.. automodule:: ops.log

ops.main module
---------------

.. automodule:: ops.main

ops.model module
----------------

.. automodule:: ops.model


ops.pebble module
-----------------

.. automodule:: ops.pebble


ops.testing module
------------------

.. automodule:: ops.testing


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
